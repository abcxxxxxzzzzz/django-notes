from django.contrib import admin
from blog.models import Category,Tag,Post
from mdeditor.widgets import MDEditorWidget
from django.db import models

class ExampleModelAdmin(admin.ModelAdmin):
    formfield_overrides = {
        models.TextField: {'widget': MDEditorWidget}
    }

class PostAdmin(ExampleModelAdmin):
    exclude = ['looks']
    list_display = ['title','excerpt_validity', 'looks', 'category', 'show_tag', 'ct_time', 'mf_time']
    list_display_links = ['title']
    search_fields=['title']        # 以title搜索
    list_filter = ['category']     # 过滤
    list_per_page = 20             # 分页
    # list_editable = ['category'] # 列表编辑

    # 实现多对多显示在后台
    def show_tag(self, obj):
        tag_list = []
        for tag in obj.tag.all():
            tag_list.append(tag.name)
        return ','.join(tag_list)
    show_tag.short_description = '标签'






class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'icon']

admin.site.register(Category,CategoryAdmin)
admin.site.register(Tag)
admin.site.register(Post,PostAdmin)
