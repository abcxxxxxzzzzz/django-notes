from django import template
from blog.models import Tag, Category,Post
from django.db.models.aggregates import Count
from blog.paginator import get_page


# 创建模板库对象
register = template.Library()

@register.simple_tag
def get_categories():
    return Category.objects.annotate(num_posts=Count('post'))
    # return Category.objects.all()
    # return Category.objects.annotate(num_posts=Count('post')).filter(num_posts__gt=0)
    
    
@register.simple_tag
def get_tags():
    return Tag.objects.all()




# @register.simple_tag
# def get_recent_posts(num=10):
#     # 查询最近时间的前10个文章
#     posts=Post.objects.all().order_by('-ct_time')[:num]
#     return posts