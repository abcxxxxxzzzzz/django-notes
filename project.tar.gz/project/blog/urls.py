from django.urls import path,re_path
from blog import views

urlpatterns = [
    re_path(r'^$', views.index, name='index'),

    # ^: 以什么开头， $是以什么结尾。 [0-9]指单个数字, +代表前面的字符出现1次或者多次。
    # (?P<pk>[0-9]+) 关键字匹配
    # /post/1/   ====> 1满足正则规则的， 将pk=1
    re_path(r'^post/(?P<id>[0-9]+)/$', views.detail, name='detail'),
    re_path(r'^category/(?P<id>[0-9]+)/$', views.category, name='category'),
    re_path(r'^tag/(?P<id>[0-9]+)/$', views.tag, name='tag'),
    re_path(r'^serarch/', views.serarch, name='serarch'),
    # re_path(r'^test/$', views.detail_copy, name='detail_copy'),
]



