from django.core.paginator import Paginator,EmptyPage, PageNotAnInteger



def get_page(request,obj):
    paginator = Paginator(obj,20)
    page = request.GET.get('page')
    try:
        obj = paginator.page(page)
    except PageNotAnInteger:
        obj = paginator.page(1)
    except EmptyPage:
        obj = paginator.page(paginator.num_pages)
    return obj