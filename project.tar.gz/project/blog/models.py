from django.db import models
from django.urls import reverse
from mdeditor.fields import MDTextField

# Create your models here.


class Category(models.Model):
    ''' 分类表 '''
    name = models.CharField(max_length=100,verbose_name='分类')
    icon = models.CharField(max_length=100, verbose_name='图标参数', help_text='参考： https://feathericons.com/')

    def __str__(self):
        return self.name


class Tag(models.Model):
    ''' 标签表 '''
    name = models.CharField(max_length=100, verbose_name='标签')

    def __str__(self):
        return self.name


class Post(models.Model):
    ''' 文章表 '''
    title = models.CharField(max_length=100,verbose_name='标题')
    # image = models.ImageField(upload_to='avatar/', null=True, blank=True, verbose_name='文章照片', help_text='请上传大小为64px X 64px')
    body = MDTextField(verbose_name='内容')
    ct_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    mf_time = models.DateTimeField(auto_now=True, verbose_name='修改时间')
    excerpt = models.CharField(max_length=200, blank=True, null=True,verbose_name='内容摘要')
    looks = models.PositiveIntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=False,verbose_name='归属分类')
    tag = models.ManyToManyField(Tag, blank=True, null=True,verbose_name='归属标签')
    # author = models.ForeignKey(User)                         # 作者

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        ''' 
        # 自定义 get_absolute_url 方法 
        # 记得从 django.urls 中导入 reverse 函数
        # reverse相当于Flask里面的url_for， 根据视图函数名称反向获取对应的路由地址.
        # /post/1/
        '''
        return reverse('detail', kwargs={'id': self.id})

    # 当有访问页面，自动 + 1
    def increase_looks(self):
        self.looks += 1
        self.save(update_fields=['looks'])

    # 当字符串超过 40 个字符的时候，用 ... 代替
    def excerpt_validity(self):
        if len(str(self.excerpt)) > 40:
            return '{}...'.format(str(self.excerpt)[0:40])
        return str(self.excerpt)