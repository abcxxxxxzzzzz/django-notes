from django.core import paginator
from django.shortcuts import get_object_or_404, redirect, render
from blog.models import Post,Category, Tag
import markdown
import re
from django.utils.text import slugify
from markdown.extensions.toc import TocExtension
from blog.paginator import get_page
from django.contrib import messages
from django.db.models import Q




def index(request):
    post_list = Post.objects.all().order_by('-ct_time')
    post_list = get_page(request,obj=post_list)
    return render(request, 'blog/index.html', locals())



def detail(request,id):
    post = get_object_or_404(Post, id=id)
    post.increase_looks()
    md = markdown.Markdown(extensions=[
        'markdown.extensions.extra',
        'markdown.extensions.codehilite',
        # 'markdown.extensions.toc',    # 使用这个方法显示的数字描边，无法显示中文： http://xxxx/post/3/#_14
        TocExtension(slugify=slugify),  # TocExtension 在实例化时其 slugify 参数可以接受一个函数，这个函数将被用于处理标题的锚点值
    ])

    post.body = md.convert(post.body)

    m = re.search(r'<div class="toc">\s*<ul>(.*)</ul>\s*</div>', md.toc, re.S)
    post.toc = m.group(1) if m is not None else ''
    return render(request, 'blog/post_detail.html', context={'post': post})



def category(request, id):
    """根据分类的id显示该分类的所有博客信息"""
    # 记得在开始部分导入 Category 类
    cate = get_object_or_404(Category, id=id)
    post_list = Post.objects.filter(category=cate).order_by('-ct_time')
    post_list = get_page(request, obj=post_list)
    return render(request, 'blog/category_post.html', context={'post_list': post_list})




def tag(request, id):
    cate = get_object_or_404(Tag, id=id)
    post_list = Post.objects.filter(tag=cate).order_by('-ct_time')
    # return render(request, 'blog/category_post.html', context={'post_list': post_list})
    post_list = get_page(request, obj=post_list)
    return render(request, 'blog/category_post.html', context={'post_list': post_list})





def serarch(request):
    q = request.GET.get('q')
    if not q:
        error_msg = "请输入搜索关键词"
        messages.add_message(request, messages.ERROR, error_msg, extra_tags='danger')
        return redirect('index')
    post_list = Post.objects.filter(Q(title__icontains=q) | Q(body__icontains=q)).order_by('-ct_time')
    return render(request, 'blog/index.html', context={'post_list': post_list})